#include <stdio.h>
#include "test.h"

int main(int argc, char **argv){
	runTests();
}